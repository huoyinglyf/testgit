#!/bin/bash

checkTable()
{
    ips=$1
    table=$2
    i=0
    echo Checking $table ...
    for ip in $ips 
    do
        count=`mysql -h "$ip" -e "select count(*) from $table" -uartogrid -partogrid 2>&1|grep "[0-9]"`
        a[$i]="$count"
        echo "  $ip: ${a[i]}"
        i=`expr $i + 1` 
    done
    if [ ${a[0]} != ${a[1]} ]; then
        echo Warning $table length are different!!
    fi
}

thisDir="$(cd `dirname "$0"` && pwd )"
cd "$thisDir"

tables=`cat tables.txt`
ips=`cat ips.txt`

if [ -z "$ips" ]; then
    echo empty servers to check
    exit 0
fi
if [ -z "$tables" ]; then
    echo please put tables in tables.txt
    exit 0
fi


for table in $tables
do
    checkTable "$ips" "$table"
done    
